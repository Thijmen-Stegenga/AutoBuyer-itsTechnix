# fut21-web-app 

Tampermonkey scripts for FUT 21 autobuyer functionality.

ONLY for player search (non consumables and other shit)!

**Works only on English language of FUT 21 web app (https://www.ea.com/fifa/ultimate-team/web-app/)!**

The software is provided "as is" without warranty of any kind, either express or implied. Use it at your own risk.

**All questions that I cannot answer (for obvious reasons, I am not responsible for the server side of the application) will be closed.**

[Changelog](https://github.com/oRastor/fut21-web-app/blob/master/CHANGELOG.md)
